public class BufferBench implements Benchable{
	public void run(int iterations,int delta,int len){
		for(int r=0;r<iterations;r++){
			StringBuffer sb=new StringBuffer(delta);
			for(int i=0;i<len;i++)
				sb.append("x");
			String s=sb.toString();
		}
	}
}