public class BuilderBench implements Benchable{
	public void run(int iterations,int delta,int len){
		for(int r=0;r<iterations;r++){
			StringBuilder sb=new StringBuilder(delta);
			for(int i=0;i<len;i++)
				sb.append("x");
			String s=sb.toString();
		}
	}
}