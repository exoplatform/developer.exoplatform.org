import java.util.*;
public class Bench{
	private static int MIN_WARMUP=5;
	private static int MAX_WARMUP=25;
	private static int LEN=4096;
	private int runs=5;//should be odd
	private Benchable bench;
	private int iterations=0;
	public static void main(String[]args){
		if(args.length!=3&&args.length!=5&&args.length!=6){
			System.out.println("usage:");
			System.out.println("\njava Bench <iterations> <from> <to> <inc> <delta> <Benchable>");
			System.out.println("\njava Bench <iterations> <from> <to> <inc> <Benchable>");
			System.out.println("\njava Bench <iterations> <delta> <Benchable>");
			System.exit(1);
		}
		if(args.length==3)
			new Bench(Integer.parseInt(args[0]),args[2],0,0,0,Integer.parseInt(args[1]),0);
		else if(args.length==5)
			new Bench(Integer.parseInt(args[0]),args[4],Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]),0,1);
		else
			new Bench(Integer.parseInt(args[0]),args[5],Integer.parseInt(args[1]),Integer.parseInt(args[2]),Integer.parseInt(args[3]),Integer.parseInt(args[4]),2);

	}
	public Bench(int iterations,String cName,int from,int to,int inc,int delta,int mode){
		this.iterations=iterations;
		try{
			bench=(Benchable)Class.forName(cName).newInstance();
			warmup(delta,LEN);
			if(mode==1||mode==2){
				benchRange(cName,from,to,inc,delta,mode);
			}else{
				long res=bench(delta,LEN);
				System.out.println(cName+"("+delta+"): "+res+" ("+(res/1000000000.0)+"s)");
			}
		}catch(Exception e){
			e.printStackTrace();
			System.exit(1);
		}
	}
	private void warmup(int delta,int len){
		long fastest=Long.MAX_VALUE;
		for(int i=0;i<MAX_WARMUP;i++){
			System.out.println("warmup #"+(i+1));
			long last=run(delta,len);
			//System.out.println("took: "+last);
			if(fastest>last)
				fastest=last;
			if(i>=MIN_WARMUP-1)
				if(last>fastest)
					break;
		}
		//System.out.println("fastest: "+fastest);
	}
	private void benchRange(String cName,int from,int to,int inc,int delta,int mode){
		//int size=(to-from)/inc;
		StringBuilder sb=new StringBuilder("M ");
		for(int i=from;i<=to;i+=inc){
			long res;
			if(mode==1)
				res=bench(i,delta);
			else
				res=bench(delta,i);
			System.err.println(cName+"("+i+"): "+res+" ("+(res/1000000000.0)+"s)");
			sb.append(i);
			sb.append(',');
			sb.append((res/1000000.0));
			if(i+inc<=to)
				sb.append(" L ");
		}
		System.out.println(sb.toString());
	}
	private long bench(int delta,int len){
		long[]res=new long[runs];
		for(int i=0;i<runs;i++){
			System.err.println("run #"+(i+1));
			long last=run(delta,len);
			System.err.println("took: "+last);
			res[i]=last;
		}
		Arrays.sort(res);
		//for(int i=0;i<runs;i++)
		//	System.out.println("res["+i+"]:"+res[i]);
		//System.out.println("median:" +res[runs/2]);
		return res[runs/2];
	}
	private long run(int delta,int len){
		long start=System.nanoTime();
		bench.run(iterations,delta,len);
		return System.nanoTime()-start;
	}
}