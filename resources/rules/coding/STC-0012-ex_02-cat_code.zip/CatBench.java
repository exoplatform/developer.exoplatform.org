public class CatBench implements Benchable{
	public void run(int iterations,int delta,int len){
		for(int r=0;r<iterations;r++){
			String s="";
			for(int i=0;i<len;i++)
				s+="x";
		}
	}
}