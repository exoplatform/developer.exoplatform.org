public interface Benchable{
	public void run(int iterations,int delta,int len);
}